(function() {
  var ready;

  ready = function() {
    return $(document).on('click', '.clickable', function() {
      window.location.href = $(this).data('url');
      return false;
    });
  };

  $(document).on('ready', ready);

}).call(this);
